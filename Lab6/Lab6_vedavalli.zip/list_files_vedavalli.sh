#!/bin/bash
echo "Below are the contents of the directory"
ls -l "$1" 
