#!/bin/bash

# Print the welcome message with the username and home directory
echo "Welcome User ($USER). Your home directory is $HOME"

