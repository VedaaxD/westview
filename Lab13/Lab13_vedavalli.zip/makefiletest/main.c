#include <hellomake.h>

void main() {
  // call a function in another file
  myPrintHelloMake();

}
