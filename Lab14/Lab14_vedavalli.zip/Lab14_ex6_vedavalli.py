radius=int(input("Enter the radius:"))
pi=3.14
diameter=2*radius
circumference=2*pi*radius
area=pi*radius**2
print ("The diameter,circumference and the area of the circle of radius", radius, "is", diameter,"units,",circumference, "units,",area, "sq units,","respectively")
