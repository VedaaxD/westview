name=input("Enter your name:")
print("Hello and welcome to the world of Python,", name,"!")

